<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Anggota</title>
    <!-- script -->
    <!-- script validasi -->
    <script>
        (() => {
            'use strict'
            const forms = document.querySelectorAll('.needs-validation')
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');

        * {
            font-family: 'Poppins', sans-serif;
        }

        .btn-primary {
            background-color: rgba(0, 128, 255, 0.100);
            color: #2f7af4;
            border: 0ch;
        }

        .btn-primary:hover {
            transform: scale(1.1);
        }

        .btn-danger {
            background-color: rgba(255, 0, 0, 0.100);
            color: red;
            border: 0ch;
        }

        .btn-danger:hover {
            transform: scale(1.1);
        }
    </style>
</head>

<body>
    <!-- kontainer form dan gambar -->
    <div class="container col-xxl-8 px-4 py-3 mt-4 mb-5 rounded-5">
        <div class="row flex-lg-row align-items-center g-5 py-0 ">
            <!-- bagian form -->
            <div class="col-lg-7 p-1 p-lg-4 pt-lg-0 animate__animated animate__fadeInLeft">
                <div class="container px-4 pt-4 pb-3 shadow-lg rounded-5">
                    <div class="card-header border-bottom  mb-4 p-1" style="color: #2f7af4;">
                        <h4><i class="fa-solid fa-user-plus me-2"></i>Tambah Data Anggota BPJS</h4>
                    </div>
                    <!-- form -->
                    <form action="<?php echo base_url('c_home/fungsi_tambah_anggota') ?>" method="post"
                        class="needs-validation" novalidate>
                        <div class="mb-3 row">
                            <label for="id_anggota" class="col-sm-3 col-form-label">ID Anggota</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="id_anggota" placeholder="ID Anggota"
                                    required>
                                <div class="invalid-feedback">
                                    Wajib diisi !
                                </div>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="nama" class="col-sm-3 col-form-label">Nama</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="nama" placeholder="Nama" required>
                                <div class="invalid-feedback">
                                    Wajib diisi !
                                </div>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="jenis_kelamin" class="col-sm-3 col-form-label">Jenis Kelamin</label>
                            <div class="col-sm-9">
                                <select value="" class="form-select" name="jenis_kelamin" required>
                                    <option selected disabled value="">Pilih Jenis Kelamin</option>
                                    <option value="Laki-laki">Laki-Laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                                <div class="invalid-feedback">
                                    Wajib diisi !
                                </div>
                            </div>
                        </div>
                        <div class="mb-4 row">
                            <label for="tanggal_lahir" class="col-sm-3 col-form-label">Tanggal Lahir</label>
                            <div class="col-sm-9">
                                <input type="date" class="form-control" name="tanggal_lahir" placeholder="YYYY-MM-DD"
                                    required>
                                <div class="invalid-feedback">
                                    Wajib diisi !
                                </div>
                            </div>
                        </div>
                        <!-- tombol -->
                        <div class="mb-3 row">
                            <div class="col">
                                <!-- tombol tambah/simpan -->
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fa-solid fa-floppy-disk"></i>
                                    Simpan
                                </button>
                                <!-- tombol kembali -->
                                <a href="<?php echo base_url('c_home/utama') ?>" type="button" class="btn btn-danger">
                                    <i class="fa-solid fa-reply"></i>
                                    Kembali
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- bagian gambar -->
            <div class="col-12 col-sm-12 col-lg-5 shadow-lg rounded-5 animate__animated animate__zoomIn">
                <img src="<?php echo base_url('assets/img/anggota-bpjs.jpg') ?>" class="d-block mx-lg-auto img-fluid"
                    alt="Anggota_BPJS">
            </div>
        </div>
    </div>
</body>

</html>