<?php
session_start();
defined('BASEPATH') or exit('No direct script access allowed');

class c_home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_models');
	}

	// fungsi tampilan awal
	public function index()
	{
		$this->load->view('v_landing_page');
	}

	// fungsi load halaman utama
	public function utama()
	{
		$queryAllAnggota = $this->m_models->getDataAnggota();
		$queryAllMedis = $this->m_models->getDataMedis();
		$DATA = array('queryAllAgt' => $queryAllAnggota, 'queryAllMds' => $queryAllMedis);
		$this->load->view('utama', $DATA);
	}

	// fungsi load edit_anggota
	public function edit_anggota($id_anggota)
	{
		$queryAnggotaDetail = $this->m_models->getDataAnggotaDetail($id_anggota);
		$DATA = array('queryAgtDetail' => $queryAnggotaDetail);
		$this->load->view('edit_anggota', $DATA);
	}

	// fungsi load edit_medis
	public function edit_medis($id_rekam_medis)
	{
		$queryMedisDetail = $this->m_models->getDataMedisDetail($id_rekam_medis);
		$DATA = array('queryMdsDetail' => $queryMedisDetail);
		$this->load->view('edit_medis', $DATA);
	}

	// fungsi tambah anggota
	public function fungsi_tambah_anggota()
	{
		$id_anggota = $this->input->post('id_anggota');
		$nama = $this->input->post('nama');
		$jenis_kelamin = $this->input->post('jenis_kelamin');
		$tanggal_lahir = $this->input->post('tanggal_lahir');

		$ArrTambahAnggota = array(
			'id_anggota' => $id_anggota,
			'nama' => $nama,
			'jenis_kelamin' => $jenis_kelamin,
			'tanggal_lahir' => $tanggal_lahir
		);

		$this->m_models->insertDataAnggota($ArrTambahAnggota);
		    if ($this) {
				$_SESSION['eksekusi'] = "Anggota (ID:$id_anggota) dengan nama '$nama' berhasil ditambahkan";
				redirect(base_url('c_home/utama'));
			}
			
	}

	// fungsi tambah medis
	public function fungsi_tambah_medis()
	{
		$id_rekam_medis = $this->input->post('id_rekam_medis');
		$id_anggota = $this->input->post('id_anggota');
		$tanggal_rekam = $this->input->post('tanggal_rekam');
		$gejala = $this->input->post('gejala');
		$tindakan = $this->input->post('tindakan');
		$resep_obat = $this->input->post('resep_obat');

		$ArrTambahMedis = array(
			'id_rekam_medis' => $id_rekam_medis,
			'id_anggota' => $id_anggota,
			'tanggal_rekam' => $tanggal_rekam,
			'gejala' => $gejala,
			'tindakan' => $tindakan,
			'resep_obat' => $resep_obat
		);

		$this->m_models->insertDataMedis($ArrTambahMedis);
		if ($this) {
			$_SESSION['eksekusi'] = "Riwayat Rekam Medis (ID:$id_rekam_medis) dengan ID Anggota '$id_anggota' berhasil ditambahkan";
			redirect(base_url('c_home/utama'));
		}
	}

	// fungsi edit anggota
	public function fungsi_edit_anggota()
	{
		$id_anggota = $this->input->post('id_anggota');
		$nama = $this->input->post('nama');
		$jenis_kelamin = $this->input->post('jenis_kelamin');
		$tanggal_lahir = $this->input->post('tanggal_lahir');

		$ArrUpdateAnggota = array(
			'nama' => $nama,
			'jenis_kelamin' => $jenis_kelamin,
			'tanggal_lahir' => $tanggal_lahir
		);

		$this->m_models->updateDataAnggota($id_anggota, $ArrUpdateAnggota);
		if ($this) {
			$_SESSION['eksekusi'] = "Data anggota (ID:$id_anggota) dengan nama '$nama' berhasil diubah";
			redirect(base_url('c_home/utama'));
		}
	}

	// fungsi edit medis
	public function fungsi_edit_medis()
	{
		$id_rekam_medis = $this->input->post('id_rekam_medis');
		$id_anggota = $this->input->post('id_anggota');
		$tanggal_rekam = $this->input->post('tanggal_rekam');
		$gejala = $this->input->post('gejala');
		$tindakan = $this->input->post('tindakan');
		$resep_obat = $this->input->post('resep_obat');

		$ArrUpdateMedis = array(
			'id_anggota' => $id_anggota,
			'tanggal_rekam' => $tanggal_rekam,
			'gejala' => $gejala,
			'tindakan' => $tindakan,
			'resep_obat' => $resep_obat
		);
		
		$this->m_models->updateDataMedis($id_rekam_medis, $ArrUpdateMedis);
		if ($this) {
			$_SESSION['eksekusi'] = "Data Rekam Medis (ID:$id_rekam_medis) dengan ID Anggota '$id_anggota' berhasil diubah";
			redirect(base_url('c_home/utama'));
		}
	}

	// fungsi hapus anggota
	public function fungsi_delete_anggota($id_anggota)
	{
		$this->m_models->deleteDataAnggota($id_anggota);
		if ($this) {
			$_SESSION['eksekusi'] = "Data Anggota (ID:$id_anggota) berhasil dihapus";
			redirect(base_url('c_home/utama'));
		}
	}

	// fungsi hapus medis
	public function fungsi_delete_medis($id_rekam_medis)
	{
		$this->m_models->deleteDataMedis($id_rekam_medis);
		if ($this) {
			$_SESSION['eksekusi'] = "Data Rekam Medis (ID:$id_rekam_medis) berhasil dihapus";
			redirect(base_url('c_home/utama'));
		}
	}

	// fungsi tombol di navbar
	public function getv_landing_page()
	{
		$this->load->view('v_landing_page');
	}
	public function getv_home()
	{
		$queryAllAnggota = $this->m_models->getDataAnggota();
		$queryAllMedis = $this->m_models->getDataMedis();
		$DATA = array('queryAllAgt' => $queryAllAnggota, 'queryAllMds' => $queryAllMedis);
		$this->load->view('v_home', $DATA);
	}
	public function getv_tambah_anggota()
	{
		$this->load->view('v_tambah_anggota');
	}
	public function getv_tambah_medis()
	{
		$this->load->view('v_tambah_medis');
	}
	public function getv_edit_anggota()
	{
		$this->load->view('edit_anggota');
	}
	public function get_tambah_anggota()
	{
		$this->load->view('tambah_anggota');
	}
	public function get_tambah_medis()
	{
		$this->load->view('tambah_medis');
	}

	public function tambah_rekam_medis_anggota($id_anggota)
	{
		$queryAnggotaDetail = $this->m_models->getDataAnggotaDetail($id_anggota);
		$DATA = array('queryAgtDetail' => $queryAnggotaDetail);
		$this->load->view('tambah_rekam_medis_anggota', $DATA);
	}

	public function lihat_data_medis_anggota($id_anggota)
	{
		$queryMedisAnggotaDetail = $this->m_models->getDataMedisAnggotaDetail($id_anggota);
		$queryAnggotaDetail = $this->m_models->getDataAnggotaDetail($id_anggota);
		$DATA = array('queryMdsAgtDetail' => $queryMedisAnggotaDetail, 'queryAgtDetail' => $queryAnggotaDetail);
		$this->load->view('lihat_data_medis_anggota', $DATA);
	}
}