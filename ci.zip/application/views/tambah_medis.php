<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tambah_medis</title>
    <!-- script validasi -->
    <script>
        (() => {
            'use strict'
            const forms = document.querySelectorAll('.needs-validation')
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
</head>

<body>
    <!-- form tambah medis -->
    <form action="<?php echo base_url('c_home/fungsi_tambah_medis') ?>" method="post" class="needs-validation"
        novalidate>
        <!-- baris id rekam medis -->
        <div class="mb-3 row">
            <label for="id_rekam_medis" class="col-sm-4 col-form-label" style="text-align: left;">ID Rekam Medis</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="id_rekam_medis" placeholder="ID Rekam Medis" required>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris id anggota -->
        <div class="mb-3 row">
            <label for="id_anggota" class="col-sm-4 col-form-label" style="text-align: left;">ID Anggota</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="id_anggota" placeholder="ID Anggota" required>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris tanggal rekam -->
        <div class="mb-3 row">
            <label for="tanggal_rekam" class="col-sm-4 col-form-label" style="text-align: left;">Tanggal Rekam</label>
            <div class="col-sm-8">
                <input type="date" class="form-control" name="tanggal_rekam" placeholder="YYYY-MM-DD" required>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris gejala -->
        <div class="mb-3 row">
            <label for="gejala" class="col-sm-4 col-form-label" style="text-align: left;">Gejala</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="gejala" placeholder="Gejala" required>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris tindakan -->
        <div class="mb-3 row">
            <label for="tindakan" class="col-sm-4 col-form-label" style="text-align: left;">Tindakan</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="tindakan" placeholder="Tindakan" required>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris resep obat -->
        <div class="mb-3 row">
            <label for="resep_obat" class="col-sm-4 col-form-label" style="text-align: left;">Resep Obat</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="resep_obat" placeholder="Resep Obat">
            </div>
        </div>
        <!-- tombol -->
        <div class="mb-3 mt-4 row">
            <div class="col text-center">
                <!-- tombol tambah/simpan -->
                <button type="submit" name="aksi" class="btn btn-success">
                    <i class="fa-solid fa-floppy-disk"></i>
                    Simpan
                </button>
            </div>
        </div>
    </form>
</body>

</html>