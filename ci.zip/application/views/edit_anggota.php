<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Anggota</title>
    <!-- script validasi -->
    <script>
        (() => {
            'use strict'
            const forms = document.querySelectorAll('.needs-validation')
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
</head>

<body>
    <!-- form edit anggota -->
    <form action="<?php echo base_url('c_home/fungsi_edit_anggota') ?>" method="post" class="needs-validation"
        novalidate>
        <!-- baris id anggota -->
        <div class="mb-3 row">
            <label for="id_anggota" class="col-sm-4 col-form-label" style="text-align:left;">ID Anggota</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="id_anggota"
                    value="<?php echo $queryAgtDetail->id_anggota ?>" readonly placeholder="ID Anggota" required>
                <div class="invalid-feedback" style="text-align:left;">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris nama -->
        <div class="mb-3 row">
            <label for="nama" class="col-sm-4 col-form-label" style="text-align:left;">Nama</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="nama" value="<?php echo $queryAgtDetail->nama ?>"
                    placeholder="Nama" required>
                <div class="invalid-feedback" style="text-align:left;">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris jenis kelamin -->
        <div class="mb-3 row">
            <label for="jenis_kelamin" class="col-sm-4 col-form-label" style="text-align:left;">Jenis Kelamin</label>
            <div class="col-sm-8">
                <select value="" class="form-select" name="jenis_kelamin" required>
                    <option selected disabled value="">Pilih Jenis Kelamin</option>
                    <option <?php if ($queryAgtDetail->jenis_kelamin == "Laki-Laki") { echo "selected"; } ?>
                        value="Laki-laki">Laki-Laki</option>
                    <option <?php if ($queryAgtDetail->jenis_kelamin == "Perempuan") { echo "selected"; } ?>
                        value="Perempuan">Perempuan</option>
                </select>
                <div class="invalid-feedback" style="text-align:left;">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris tanggal lahir -->
        <div class="mb-4 row">
            <label for="tanggal_lahir" class="col-sm-4 col-form-label" style="text-align:left;">Tanggal Lahir</label>
            <div class="col-sm-8">
                <input type="date" class="form-control" name="tanggal_lahir"
                    value="<?php echo $queryAgtDetail->tanggal_lahir ?>" placeholder="YYYY-MM-DD" required>
                <div class="invalid-feedback" style="text-align:left;">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- tombol -->
        <div class="mb-3 row">
            <div class="col">
                <!-- tombol tambah/simpan -->
                <button type="submit" class="btn btn-success">
                    <i class="fa-solid fa-floppy-disk"></i>
                    Simpan Perubahan
                </button>
            </div>
        </div>
    </form>
</body>

</html>