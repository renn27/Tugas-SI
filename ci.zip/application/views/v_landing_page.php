<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>landing</title>
    <!-- script -->
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
        crossorigin="anonymous"></script>
    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <!-- animasi -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <!-- script auto typed -->
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');

        * {
            font-family: 'Poppins', sans-serif;
        }

        .btn-primary {
            background-color: rgba(0, 128, 255, 0.100);
            color: #2f7af4;
            border: 0ch;
        }

        .btn-primary:hover {
            transform: scale(1.1);
        }

        .btn-outline-secondary {
            border: 0px;
        }

        .btn-outline-secondary:hover {
            transform: scale(1.1);
            background-color: transparent;
            color: #2f7af4;
        }

        .tambah:hover {
            color: #2f7af4;
            transform: scale(1.1);
        }

        .feature-icon-small:hover {
            transform: scale(1.1);
        }

        .text-fitur {
            color: gray;
        }

        .text-fitur:hover {
            color: black;
        }

        .auto-type-welcome {
            color: #2f7af4;
        }

        .auto-type-deskripsi {
            color: black;
            ;
        }
    </style>
</head>

<body>
    <!-- isi konten -->
    <!-- kontainer welcome dan gambar -->
    <div class="container col-xxl-8 px-4 py-3 mt-4 mb-5 shadow-lg rounded-5 animate__animated animate__zoomIn">
        <div class="row flex-lg-row align-items-center g-5 py-0 ">
            <!-- bagian logo dan welcome -->
            <div class="col-lg-6 p-3 p-lg-5 pt-lg-0">
                <!-- logo -->
                <h1 class="pb-5">
                    <img class="light-mode-item navbar-brand-item"
                        src="<?php echo base_url('assets/img/logo-gif.gif') ?>" alt="logo-gif" width="100px"
                        height="100px">
                    <img class="light-mode-item navbar-brand-item"
                        src="<?php echo base_url('assets/img/text-logo-gif2.gif') ?>" alt="text-logo-gif" width="240px"
                        height="60px">
                </h1>
                <!-- welcome -->
                <h3 class="fw-bold lh-1 mb-3 mt-5 ">Hey! <span class="auto-type-welcome"></span></h3>
                <!-- script auto typed welcome -->
                <script>
                    var typed = new Typed(".auto-type-welcome", {
                        strings: ["Welcome...", "Selamat Datang...", "Aloha...", "ようこそ...", "환영합니다..."],
                        typeSpeed: 100,
                        backSpeed: 100,
                        loop: true
                    })
                </script>
                <!-- deskripsi -->
                <p class="text-muted">Disini anda dapat mengolah database dengan cepat.<br>
                    <span class="auto-type-deskripsi fw-bold"></span> data hanya dalam satu web !<br>
                    Silahkan klik mulai untuk mengolah database anda !
                </p>
                <!-- script auto typed deskripsi -->
                <script>
                    var typed = new Typed(".auto-type-deskripsi", {
                        strings: ["Menambah", "Mengedit", "Melihat", "Menghapus"],
                        typeSpeed: 100,
                        backSpeed: 100,
                        loop: true
                    })
                </script>
                <!-- tombol -->
                <div class="d-grid gap-2 d-md-flex justify-content-md-start pt-3">
                    <!-- tombol start -->
                    <a href="<?php echo base_url('c_home/utama') ?>" class="btn btn-primary btn-lg" id="btn-mulai">
                        <i class="fa-solid fa-right-to-bracket me-2"></i>Mulai
                    </a>
                    <!-- tombol fitur -->
                    <a href="#fitur" type="button" class="btn btn-outline-secondary btn-lg px-4">
                        Fitur
                        <i class="fa-solid fa-angle-down"></i>
                    </a>
                </div>
            </div>
            <!-- bagian gambar -->
            <div class="col-12 col-sm-12 col-lg-6">
                <img src="<?php echo base_url('assets/img/landing-page2.jpg') ?>" class="d-block mx-lg-auto img-fluid"
                    alt="Gambar_Home">
            </div>
        </div>
    </div>

    <!-- kontainer fitur -->
    <div class="container col-xxl-8 px-4 py-3 mt-5 shadow-lg rounded-5 animate__animated animate__zoomIn" id="fitur">
        <!-- judul -->
        <h2 class="pb-2 px-4 border-bottom  text-center">Fitur</h2>
        <div class="row g-4 py-5 px-4 row-cols-2 row-cols-lg-4">
            <!-- fitur tambah -->
            <div class="feature col text-center">
                <div
                    class="feature-icon-small d-inline-flex align-items-center justify-content-center text-bg-primary bg-gradient fs-4 rounded-5">
                    <h2><i class="fa-sharp fa-solid fa-plus me-4 ms-4 mt-2"></i></h2>
                </div>
                <div class="tambah py-1 px-2 mt-4 shadow-lg rounded-5 bg-opacity-10 bg-primary">
                    <h3 class="fs-3 mt-3">Tambah</h3>
                    <p class="text-fitur">Tambahkan data Anggota dan Rekam Medis dengan cepat kedalam database anda !
                    </p>
                </div>
            </div>
            <!-- fitur edit -->
            <div class="feature col text-center">
                <div
                    class="feature-icon-small d-inline-flex align-items-center justify-content-center text-bg-warning bg-gradient fs-4 rounded-5">
                    <h2><i class="fa-solid fa-pen me-4 ms-4 mt-2" style="color: white;"></i></h2>
                </div>
                <div class="tambah py-1 px-2 mt-4 shadow-lg rounded-5 bg-opacity-10 bg-warning">
                    <h3 class="fs-3 mt-3">Edit</h3>
                    <p class="text-fitur">Salah saat memasukkan data? Tenang, anda dapat mengedit data dengan mudah.</p>
                </div>
            </div>
            <!-- fitur lihat -->
            <div class="feature col text-center">
                <div
                    class="feature-icon-small d-inline-flex align-items-center justify-content-center text-bg-success bg-gradient fs-4 rounded-5">
                    <h2><i class="fa-solid fa-magnifying-glass me-4 ms-4 mt-2"></i></h2>
                </div>
                <div class="tambah py-1 px-2 mt-4 shadow-lg rounded-5 bg-opacity-10 bg-success">
                    <h3 class="fs-3 mt-3">Lihat</h3>
                    <p class="text-fitur">Disini kami memudahkan anda untuk melihat data dengan lengkap, rapi dan cepat
                        !</p>
                </div>
            </div>
            <!-- fitur hapus -->
            <div class="feature col text-center">
                <div
                    class="feature-icon-small d-inline-flex align-items-center justify-content-center text-bg-danger bg-gradient fs-4 rounded-5">
                    <h2><i class="fa-solid fa-trash me-4 ms-4 mt-2"></i></h2>
                </div>
                <div class="tambah py-1 px-2 mt-4 shadow-lg rounded-5 bg-opacity-10 bg-danger">
                    <h3 class="fs-3 mt-3">Hapus</h3>
                    <p class="text-fitur">Ingin menghapus data? disini kami menyediakan fitur hapus data hanya dengan
                        satu klik !</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="container">
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
            <div class="col-md-4 d-flex align-items-center">
                <!-- logo footer -->
                <a href="<?php echo base_url() ?>" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
                    <img src="<?php echo base_url('assets/img/logo-footer-baru.png') ?>" alt="Logo" width="20"
                        height="20" class="justify-content-center">
                    <img src="<?php echo base_url('assets/img/text-logo-footer.png') ?>" alt="Logo" width="80"
                        height="20" class="justify-content-center">
                </a>
                <!-- text footer -->
                <span class="mb-3 mb-md-0 text-muted">© 2022 M.Rendi Alamsyah <i class="fa-solid fa-code"></i></span>
            </div>
            <!-- logo sosmed -->
            <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
                <li class="ms-3"><a class="text-muted" href="#">
                        <h5><i class="fa-brands fa-twitter"></i></h5>
                    </a></li>
                <li class="ms-3"><a class="text-muted" href="#">
                        <h5><i class="fa-brands fa-instagram"></i></h5>
                    </a></li>
                <li class="ms-3"><a class="text-muted" href="#">
                        <h5><i class="fa-brands fa-facebook"></i></h5>
                    </a></li>
            </ul>
        </footer>
    </div>
</body>

</html>