<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- data tables -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('DataTables/datatables.min.css') ?>" />
    <script type="text/javascript" src="<?php echo base_url('DataTables/datatables.min.js') ?>"></script>
    <!-- ajax -->
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <!-- enable tooltip -->
    <script>
        const tooltipTriggerList = document.querySelectorAll('[data-bstooltip-toggle="tooltip"]')
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
    </script>
    <!-- style -->
    <style>
        .bag-tbh:hover {
            transform: scale(1.02);
        }
        .btn-primary {
            background-color: rgba(0, 128, 255, 0.150);
            color: #2f7af4;
            border: 0ch;
        }
        .btn-success {
            background-color: rgba(0, 128, 0, 0.150);
            color:green;
            border: 0ch;
        }
        .btn-warning {
            background-color: rgba(255, 165, 0, 0.150);
            color:orange;
            border: 0ch;
        }
        .btn-danger {
            background-color: rgba(255, 0, 0, 0.150);
            color: red;
            border: 0ch;
        }
        .btn-primary:hover {
            transform: scale(1.07);
        }
        .btn-success:hover {
            transform: scale(1.07);
        }
        .btn-warning:hover {
            transform: scale(1.07);
        }
        .btn-danger:hover {
            transform: scale(1.07);
        }

    </style>
</head>

<body>
    <!-- row tambah anggota dan medis -->
    <div class="row row-cols-1 row-cols-md-2">
        <!-- bagian tambah anggota -->
        <div class="col pt-4 animate__animated animate__fadeInLeft">
            <!-- container tambah anggota -->
            <div class="container bag-tbh text-center rounded-5 shadow-lg">
                <h4 class="pt-4" style="color: #2f7af4">
                    <i class="fa-solid fa-user-group me-1"></i>
                    Anggota BPJS
                </h4>
                <div class="pt-0 mt-0">
                    <!-- gambar -->
                    <div class="container mt-2 mb-2" style="max-inline-size: 265px;">
                        <img src="<?php echo base_url('assets/img/anggota-bpjs-crop.jpg') ?>"
                            class="d-block mx-lg-auto img-fluid" alt="Anggota_BPJS">
                    </div>
                    <p class="card-text">Klik untuk menambahkan data Anggota BPJS</p>
                    <!-- tombol tambah data anggota -->
                    <button type="button" id="btn-tambah-anggota" class="btn btn-primary rounded-4 mb-2"
                        data-bs-toggle="modal" data-bs-target="#modal-tambah-anggota">
                        <i class="fa-solid fa-user-plus me-1"></i>
                        Tambah Data Anggota
                    </button>
                    <br>
                    <!-- tombol lihat data anggota -->
                    <a href="#con-tab-agt" type="button" class="btn btn-light rounded-4 mb-4">
                        <i class="fa-solid fa-magnifying-glass me-1"></i>
                        Lihat Data Anggota
                        <i class="fa-solid fa-angle-down"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- bagian tambah medis -->
        <div class="col pt-4 animate__animated animate__fadeInRight">
            <!-- container tambah medis -->
            <div class="container bag-tbh text-center rounded-5 shadow-lg">
                <h4 class="pt-4" style="color: #2f7af4">
                    <i class="fa-solid fa-heart-pulse me-1"></i>
                    Rekam Medis
                </h4>
                <div class="pt-0 mt-0">
                    <!-- gambar -->
                    <div class="container mt-2 mb-2" style="max-inline-size: 265px;">
                        <img src="<?php echo base_url('assets/img/rekam-medis-crop.jpg') ?>"
                            class="d-block mx-lg-auto img-fluid" alt="Anggota_BPJS">
                    </div>
                    <p class="card-text">Klik untuk menambahkan data Rekam Medis</p>
                    <!-- tombol tambah data medis -->
                    <button type="button" id="btn-tambah-medis" class="btn btn-primary rounded-4 mb-2"
                        data-bs-toggle="modal" data-bs-target="#modal-tambah-medis">
                        <i class="fa-solid fa-file-medical me-2"></i>
                        Tambah Data Rekam Medis
                    </button>
                    <br>
                    <!-- tombol lihat data medis -->
                    <a href="#con-tab-mds" type="button" class="btn btn-light rounded-4 mb-4">
                        <i class="fa-solid fa-magnifying-glass me-1"></i>
                        Lihat Data Rekam Medis
                        <i class="fa-solid fa-angle-down"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- modal tambah anggota-->
    <div class="modal fade" id="modal-tambah-anggota" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content rounded-4 shadow">
                <div class="modal-header bg-primary bg-opacity-10">
                    <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="fa-solid fa-user-plus me-2"></i>Tambah Anggota BPJS</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <!-- isi modal tambah anggota diambil dari halaman tambah anggota -->
                <div class="modal-body" id="content-tambah-anggota"></div>
                <!-- tombol batal -->
                <div class="modal-footer flex-column border-top-0">
                    <button type="button" class="btn btn-light w-100 mx-0" data-bs-dismiss="modal">Batal</button>
                </div>
            </div>
        </div>
    </div>
    <!-- ajax modal tambah anggota -->
    <script type="text/javascript">
        $(document).ready(function () {
            $("#btn-tambah-anggota").click(function () {
                view_tambah_anggota();
            })
        })
        function view_tambah_anggota() {
            $.ajax({
                method: "POST",
                url: "<?php echo base_url('c_home/get_tambah_anggota') ?>",
                data: {}
            })
                .done(function (msg) {
                    $("#content-tambah-anggota").html(msg);
                });
        }
    </script>

    <!-- modal tambah medis-->
    <div class="modal fade" id="modal-tambah-medis" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content rounded-4 shadow">
                <div class="modal-header bg-primary bg-opacity-10">
                    <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="fa-solid fa-file-medical me-2"></i>Tambah Rekam Medis
                    </h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <!-- isi modal tambah medis diambil dari halaman tambah medis -->
                <div class="modal-body" id="content-tambah-medis">
                </div>
                <!-- tombol batal -->
                <div class="modal-footer flex-column border-top-0">
                    <button type="button" class="btn btn-light w-100 mx-0" data-bs-dismiss="modal">Batal</button>
                </div>
            </div>
        </div>
    </div>
    <!-- ajax modal tambah medis -->
    <script type="text/javascript">
        $(document).ready(function () {
            $("#btn-tambah-medis").click(function () {
                view_tambah_medis();
            })
        })
        function view_tambah_medis() {
            $.ajax({
                method: "POST",
                url: "<?php echo base_url('c_home/get_tambah_medis') ?>",
                data: {}
            })
                .done(function (msg) {
                    $("#content-tambah-medis").html(msg);
                });
        }
    </script>

    <!-- container table anggota -->
    <div class="container shadow-lg rounded-5 mt-5 pt-4 pb-5 px-5" id="con-tab-agt">
        <h4 class="mb-4 border-bottom pb-2 mt-2" style="color:#2f7af4;">
            <i class="fa-solid fa-table me-2"></i>Tabel Anggota BPJS
        </h4>
        <!-- table anggota bpjs -->
        <div class="table-responsive mb-1 mt-3">
            <table class="table table-hover table-bordered align-middle" id="tableAgt">
                <thead>
                    <tr class="bg-primary bg-opacity-10">
                        <th>
                            <center>No</center>
                        </th>
                        <th>
                            <center>ID Anggota</center>
                        </th>
                        <th>
                            <center>Nama</center>
                        </th>
                        <th>
                            <center>Jenis Kelamin</center>
                        </th>
                        <th>
                            <center>Tanggal Lahir</center>
                        </th>
                        <th>
                            <center>Aksi</center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $countagt = 0;
                    foreach ($queryAllAgt as $rowagt) {
                        $countagt = $countagt + 1;
                    ?>
                    <tr>
                        <td>
                            <center>
                                <?php echo $countagt ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowagt->id_anggota ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowagt->nama ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowagt->jenis_kelamin ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowagt->tanggal_lahir ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <!-- tombol lihat data medis anggota -->
                                <button type="button" data-bstooltip-toggle="tooltip" data-bs-placement="top"
                                    data-bs-title="Lihat Data"
                                    id="btn-lihat-data-medis-anggota-<?php echo $rowagt->id_anggota ?>"
                                    class="btn btn-success btn-sm mb-1" data-bs-toggle="modal"
                                    data-bs-target="#modal-lihat-data-medis-anggota-<?php echo $rowagt->id_anggota ?>">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                                <!-- modal Lihat data medis anggota-->
                                <div class="modal fade"
                                    id="modal-lihat-data-medis-anggota-<?php echo $rowagt->id_anggota ?>"
                                    tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content rounded-4 shadow">
                                            <div class="modal-header bg-success bg-opacity-10">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="fa-solid fa-magnifying-glass me-2"></i>Lihat Data :
                                                    <?php echo $rowagt->nama ?>
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <!-- isi modal edit diambil dari hamalan edit_anggota -->
                                            <div class="modal-body"
                                                id="content-lihat-data-medis-anggota-<?php echo $rowagt->id_anggota ?>">
                                            </div>
                                            <!-- tombol batal -->
                                            <div class="modal-footer flex-column border-top-0">
                                                <button type="button" class="btn btn-light w-100 mx-0"
                                                    data-bs-dismiss="modal">Tutup</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- ajax modal Lihat data medis anggota -->
                                <script type="text/javascript">
                                    $(document).ready(function () {
                                        $("#btn-lihat-data-medis-anggota-<?php echo $rowagt->id_anggota ?>").click(function () {
                                            viewlihat_data_medis_anggota<?php echo $rowagt->id_anggota ?> ();
                                        })
                                    })
                                    function viewlihat_data_medis_anggota<?php echo $rowagt->id_anggota ?> () {
                                        $.ajax({
                                            method: "POST",
                                            url: "<?php echo base_url('/c_home/lihat_data_medis_anggota') ?>/<?php echo $rowagt->id_anggota ?>",
                                            data: {}
                                        })
                                            .done(function (msg) {
                                                $("#content-lihat-data-medis-anggota-<?php echo $rowagt->id_anggota ?>").html(msg);
                                            });
                                    }
                                </script>

                                <!-- tombol tambah rekam medis anggota -->
                                <button type="button" data-bstooltip-toggle="tooltip" data-bs-placement="top"
                                    data-bs-title="Tambah Rekam Medis"
                                    id="btn-tambah-rekam-medis-anggota-<?php echo $rowagt->id_anggota ?>"
                                    class="btn btn-primary btn-sm mb-1" data-bs-toggle="modal"
                                    data-bs-target="#modal-tambah-rekam-medis-anggota-<?php echo $rowagt->id_anggota ?>">
                                    <i class="fa-solid fa-file-medical"></i>
                                </button>
                                <!-- modal tambah rekam medis anggota-->
                                <div class="modal fade"
                                    id="modal-tambah-rekam-medis-anggota-<?php echo $rowagt->id_anggota ?>"
                                    tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content rounded-4 shadow">
                                            <div class="modal-header bg-primary bg-opacity-10">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="fa-solid fa-file-medical me-2"></i>Tambah Rekam Medis :
                                                    <?php echo $rowagt->nama ?>
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <!-- isi modal edit diambil dari hamalan edit_anggota -->
                                            <div class="modal-body"
                                                id="content-tambah-rekam-medis-anggota-<?php echo $rowagt->id_anggota ?>">
                                            </div>
                                            <!-- tombol batal -->
                                            <div class="modal-footer flex-column border-top-0">
                                                <button type="button" class="btn btn-light w-100 mx-0"
                                                    data-bs-dismiss="modal">Batal</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- ajax modal tambah rekam medis anggota -->
                                <script type="text/javascript">
                                    $(document).ready(function () {
                                        $("#btn-tambah-rekam-medis-anggota-<?php echo $rowagt->id_anggota ?>").click(function () {
                                            viewtambah_rekam_medis_anggota<?php echo $rowagt->id_anggota ?> ();
                                        })
                                    })
                                    function viewtambah_rekam_medis_anggota<?php echo $rowagt->id_anggota ?> () {
                                        $.ajax({
                                            method: "POST",
                                            url: "<?php echo base_url('/c_home/tambah_rekam_medis_anggota') ?>/<?php echo $rowagt->id_anggota ?>",
                                            data: {}
                                        })
                                            .done(function (msg) {
                                                $("#content-tambah-rekam-medis-anggota-<?php echo $rowagt->id_anggota ?>").html(msg);
                                            });
                                    }
                                </script>

                                <!-- tombol edit anggota -->
                                <button type="button" data-bstooltip-toggle="tooltip" data-bs-placement="top"
                                    data-bs-title="Edit Data" id="btn-edit-anggota-<?php echo $rowagt->id_anggota ?>"
                                    class="btn btn-warning btn-sm mb-1" data-bs-toggle="modal"
                                    data-bs-target="#modal-edit-anggota-<?php echo $rowagt->id_anggota ?>">
                                    <i class="fa-solid fa-pen"></i>
                                </button>
                                <!-- modal edit anggota-->
                                <div class="modal fade" id="modal-edit-anggota-<?php echo $rowagt->id_anggota ?>"
                                    tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content rounded-4 shadow">
                                            <div class="modal-header bg-warning bg-opacity-10">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="fa-solid fa-pen me-2"></i>Edit Data Anggota :
                                                    <?php echo $rowagt->nama ?>
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <!-- isi modal edit diambil dari hamalan edit_anggota -->
                                            <div class="modal-body"
                                                id="content-edit-anggota-<?php echo $rowagt->id_anggota ?>"></div>
                                            <!-- tombol batal -->
                                            <div class="modal-footer flex-column border-top-0">
                                                <button type="button" class="btn btn-light w-100 mx-0"
                                                    data-bs-dismiss="modal">Batal</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- ajax modal edit anggota -->
                                <script type="text/javascript">
                                    $(document).ready(function () {
                                        $("#btn-edit-anggota-<?php echo $rowagt->id_anggota ?>").click(function () {
                                            viewedit_anggota_<?php echo $rowagt->id_anggota ?> ();
                                        })
                                    })
                                    function viewedit_anggota_<?php echo $rowagt->id_anggota ?> () {
                                        $.ajax({
                                            method: "POST",
                                            url: "<?php echo base_url('/c_home/edit_anggota') ?>/<?php echo $rowagt->id_anggota ?>",
                                            data: {}
                                        })
                                            .done(function (msg) {
                                                $("#content-edit-anggota-<?php echo $rowagt->id_anggota ?>").html(msg);
                                            });
                                    }
                                </script>
                                <!-- tombol hapus anggota-->
                                <button type="button" data-bstooltip-toggle="tooltip" data-bs-placement="top"
                                    data-bs-title="Hapus" class="btn btn-danger btn-sm mb-1" data-bs-toggle="modal"
                                    data-bs-target="#modal-hapus-<?php echo $rowagt->id_anggota ?>">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                                <!-- modal hapus anggota -->
                                <div class="modal fade" id="modal-hapus-<?php echo $rowagt->id_anggota ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content rounded-4 shadow">
                                            <div class="modal-header bg-danger bg-opacity-25">
                                                <h1 class="modal-title fs-6" id="exampleModalLabel"><i class="fa-solid fa-trash me-2"></i>Hapus Data</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body bg-danger bg-opacity-10">
                                                Anda Yakin Ingin Menghapus Data "
                                                <?php echo $rowagt->nama ?>"?
                                            </div>
                                            <div class="modal-footer bg-danger bg-opacity-10">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                    <i class="fa-solid fa-xmark me-1"></i>
                                                    Batal
                                                </button>
                                                <a href="<?php echo base_url('/c_home/fungsi_delete_anggota') ?>/<?php echo $rowagt->id_anggota ?>"
                                                    type="button" class="btn btn-danger">
                                                    <i class="fa-solid fa-check me-1"></i>
                                                    Hapus
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </center>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
                <!-- script DataTable anggota bpjs -->
                <script>
                    $(document).ready(function () {
                        $('#tableAgt').DataTable();
                    });
                </script>
            </table>
        </div>
    </div>

    <!-- container table rekam medis -->
    <div class="container shadow-lg rounded-5 mt-5 pt-4 pb-5 px-5" id="con-tab-mds">
        <h4 class="mb-4 border-bottom pb-2 mt-2" style="color:#2f7af4;">
            <i class="fa-solid fa-table me-2"></i>Tabel Riwayat Rekam Medis
        </h4>
        <!-- table rekam medis -->
        <div class="table-responsive mb-1 mt-3">
            <table class="table table-hover table-bordered align-middle" id="table-medis">
                <thead>
                    <tr class="bg-primary bg-opacity-10">
                        <th>
                            <center>No</center>
                        </th>
                        <th>
                            <center>ID Rekam Medis</center>
                        </th>
                        <th>
                            <center>ID Anggota</center>
                        </th>
                        <th>
                            <center>Tanggal Rekam</center>
                        </th>
                        <th>
                            <center>Gejala</center>
                        </th>
                        <th>
                            <center>Tindakan</center>
                        </th>
                        <th>
                            <center>Resep Obat</center>
                        </th>
                        <th>
                            <center>Aksi</center>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $countmds = 0;
                    foreach ($queryAllMds as $rowmds) {
                        $countmds = $countmds + 1;
                    ?>
                    <tr>
                        <td>
                            <center>
                                <?php echo $countmds ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowmds->id_rekam_medis ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowmds->id_anggota ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowmds->tanggal_rekam ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowmds->gejala ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowmds->tindakan ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <?php echo $rowmds->resep_obat ?>
                            </center>
                        </td>
                        <td>
                            <center>
                                <!-- tombol edit medis -->
                                <button type="button" data-bstooltip-toggle="tooltip" data-bs-placement="top"
                                    data-bs-title="Edit Data" id="btn-edit-medis-<?php echo $rowmds->id_rekam_medis ?>"
                                    class="btn btn-warning btn-sm mb-1" data-bs-toggle="modal"
                                    data-bs-target="#modal-edit-medis-<?php echo $rowmds->id_rekam_medis ?>">
                                    <i class="fa-solid fa-pen"></i>
                                </button>
                                <!-- modal edit medis-->
                                <div class="modal fade" id="modal-edit-medis-<?php echo $rowmds->id_rekam_medis ?>"
                                    tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content rounded-4 shadow">
                                            <div class="modal-header bg-warning bg-opacity-10">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="fa-solid fa-pen me-2"></i>Edit Data Medis : 
                                                    <?php echo $rowmds->id_rekam_medis ?>
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <!-- isi modal edit medis diambil dari halaman edit_medis -->
                                            <div class="modal-body"
                                                id="content-edit-medis-<?php echo $rowmds->id_rekam_medis ?>"></div>
                                            <!-- tombol batal -->
                                            <div class="modal-footer flex-column border-top-0">
                                                <button type="button" class="btn btn-light w-100 mx-0"
                                                    data-bs-dismiss="modal">Batal</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- ajax modal edit medis -->
                                <script type="text/javascript">
                                    $(document).ready(function () {
                                        $("#btn-edit-medis-<?php echo $rowmds->id_rekam_medis ?>").click(function () {
                                            viewedit_medis_<?php echo $rowmds->id_rekam_medis ?> ();
                                        })
                                    })
                                    function viewedit_medis_<?php echo $rowmds->id_rekam_medis ?> () {
                                        $.ajax({
                                            method: "POST",
                                            url: "<?php echo base_url('/c_home/edit_medis') ?>/<?php echo $rowmds->id_rekam_medis ?>",
                                            data: {}
                                        })
                                            .done(function (msg) {
                                                $("#content-edit-medis-<?php echo $rowmds->id_rekam_medis ?>").html(msg);
                                            });
                                    }
                                </script>
                                <!-- tombol hapus medis -->
                                <button type="button" data-bstooltip-toggle="tooltip" data-bs-placement="top"
                                    data-bs-title="Hapus" class="btn btn-danger btn-sm mb-1" data-bs-toggle="modal"
                                    data-bs-target="#modal-hapus-medis-<?php echo $rowmds->id_rekam_medis ?>">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                                <!-- Modal hapus medis -->
                                <div class="modal fade" id="modal-hapus-medis-<?php echo $rowmds->id_rekam_medis ?>"
                                    tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header bg-danger bg-opacity-25">
                                                <h1 class="modal-title fs-6" id="exampleModalLabel"><i class="fa-solid fa-trash me-2"></i>Hapus Data</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body bg-danger bg-opacity-10">
                                                Anda Yakin Ingin Menghapus Data Dengan ID "
                                                <?php echo $rowmds->id_rekam_medis ?>" ?
                                            </div>
                                            <div class="modal-footer bg-danger bg-opacity-10">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                    <i class="fa-solid fa-xmark me-1"></i>
                                                    Batal
                                                </button>
                                                <a href="<?php echo base_url('/c_home/fungsi_delete_medis') ?>/<?php echo $rowmds->id_rekam_medis ?>"
                                                    type="button" class="btn btn-danger">
                                                    <i class="fa-solid fa-check me-1"></i>
                                                    Hapus
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </center>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
                <script type="text/javascript">
                    $(document).ready(function () {
                        $('#table-medis').DataTable();
                    });
                </script>
            </table>
        </div>
    </div>
</body>

</html>