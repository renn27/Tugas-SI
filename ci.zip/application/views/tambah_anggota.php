<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tambah_anggota</title>
    <!-- script validasi -->
    <script>
        (() => {
            'use strict'
            const forms = document.querySelectorAll('.needs-validation')
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
</head>

<body>
    <!-- form tambah anggota -->
    <form action="<?php echo base_url('c_home/fungsi_tambah_anggota') ?>" method="post" class="needs-validation"
        novalidate>
        <!-- baris id anggota -->
        <div class="mb-3 row">
            <label for="id_anggota" class="col-sm-4 col-form-label">ID Anggota</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="id_anggota" placeholder="ID Anggota" required>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris nama -->
        <div class="mb-3 row">
            <label for="nama" class="col-sm-4 col-form-label">Nama</label>
            <div class="col-sm-8">
                <input type="text" class="form-control" name="nama" placeholder="Nama" required>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris jenis kelamin -->
        <div class="mb-3 row">
            <label for="jenis_kelamin" class="col-sm-4 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-8">
                <select value="" class="form-select" name="jenis_kelamin" required>
                    <option selected disabled value="">Pilih Jenis Kelamin</option>
                    <option value="Laki-laki">Laki-Laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- baris tanggal lahir -->
        <div class="mb-4 row">
            <label for="tanggal_lahir" class="col-sm-4 col-form-label">Tanggal Lahir</label>
            <div class="col-sm-8">
                <input type="date" class="form-control" name="tanggal_lahir" placeholder="YYYY-MM-DD" required>
                <div class="invalid-feedback">
                    Wajib diisi !
                </div>
            </div>
        </div>
        <!-- tombol -->
        <div class="mb-3 row">
            <div class="col text-center">
                <!-- tombol tambah/simpan -->
                <button type="submit" class="btn btn-success">
                    <i class="fa-solid fa-floppy-disk"></i>
                    Simpan
                </button>
            </div>
        </div>
    </form>
</body>

</html>