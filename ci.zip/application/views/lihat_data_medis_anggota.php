<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Data Medis Anggota</title>
</head>

<body>
    <div class="card" style="text-align: left;">
        <h6 class="card-header bg-primary bg-opacity-10"><i class="fa-solid fa-user me-2"></i>Data Anggota (ID : <?php echo $queryAgtDetail->id_anggota ?>)</h6>
        <div class="card-body">
            <p>
                Nama :
                <?php echo $queryAgtDetail->nama ?> <br>
                Jenis Kelamin :
                <?php echo $queryAgtDetail->jenis_kelamin ?> <br>
                Tanggal Lahir :
                <?php echo date(' d F Y', strtotime($queryAgtDetail->tanggal_lahir)) ?>
            </p>
        </div>
    </div>

    <div class="card mt-3" style="text-align: left;">
        <h6 class="card-header bg-primary bg-opacity-10"><i class="fa-solid fa-heart-pulse me-2"></i></i>Riwayat Rekam Medis</h6>
        <div class="card-body">
            <?php
                if ($queryMdsAgtDetail) {
                    $count = 0;
                    foreach ($queryMdsAgtDetail as $rowmdsagt) {
                        $count = $count + 1;
                ?>

            <div class="card mb-3" style="text-align: left;">
           <h6 class="card-header" style="font-weight: bold;" ><i class="fa-solid fa-calendar-days me-2"></i><?php echo date('d/m/Y',strtotime($rowmdsagt->tanggal_rekam)) ?></h6>
                <div class="card-body">
                    <p>
                       ID Rekam Medis : <?php echo $rowmdsagt->id_rekam_medis ?> <br>
                       Gejala : <?php echo $rowmdsagt->gejala ?> <br>
                       Tindakan : <?php echo $rowmdsagt->tindakan ?> <br>
                       Resep Obat : <?php echo $rowmdsagt->resep_obat ?>
                    </p>
                </div>
            </div>
            <?php
                    }
                } else {
            ?>
                <p class="text-muted" style="text-align: center;">Riwayat Rekam Medis Tidak Ditemukan  <br> <i>(<?php echo $queryAgtDetail->nama ?> belum pernah melakukan rekam medis)</i></p>
                <?php
                }
                ?>
        </div>
    </div>




</body>

</html>