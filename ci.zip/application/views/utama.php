<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Halaman Home</title>

	<!-- script -->
	<!-- bootstrap -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
		crossorigin="anonymous"></script>
	<!-- font awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
	<!-- ajax -->
	<script src="https://code.jquery.com/jquery-3.6.1.min.js"
		integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
	<!-- data tables -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('DataTables/datatables.min.css') ?>" />
	<script type="text/javascript" src="<?php echo base_url('DataTables/datatables.min.js') ?>"></script>
	<!-- animasi -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
	<!-- style -->
	<style>
		@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');

		* {
			font-family: 'Poppins', sans-serif;
		}

		.tombol-nav {
			color: black !important;
		}

		.nav-link:hover {
			background-color: rgba(0, 128, 255, 0.100) !important;
			color: #3366ff !important;
			border-radius: 0.5rem !important;
			transform: scale(1.1);
		}

		.active {
			background-color: rgba(0, 128, 255, 0.100) !important;
			color: #3366ff !important;
			border-radius: 0.5rem !important;
			font-weight: 500 !important;
		}
	</style>
</head>

<body>
	<!-- header -->
	<header class="navbar-light header-sticky">
		<!-- Logo Nav START -->
		<nav class="navbar navbar-expand-xl">
			<div class="container">
				<!-- Logo START -->
				<a class="navbar-brand" href="<?php echo base_url('') ?>">
					<img class="light-mode-item navbar-brand-item"
						src="<?php echo base_url('assets/img/logo-gif.gif') ?>" alt="logo" width=40px height=40px>
					<img class="light-mode-item navbar-brand-item"
						src="<?php echo base_url('assets/img/text-logo-gif2.gif') ?>" alt="text-logo" width=120px
						height=30px>
				</a>
				<!-- Logo END -->

				<!-- Responsive menu navbar -->
				<button class="navbar-toggler ms-auto mx-3 me-md-0 p-2" type="button" data-bs-toggle="collapse"
					data-bs-target="#navbarCategoryCollapse" aria-controls="navbarCategoryCollapse"
					aria-expanded="false" aria-label="Toggle navigation">
					<i class="fa-solid fa-bars"></i><span class="d-none d-sm-inline-block small ms-2">Menu</span>
				</button>

				<!-- Navbar Menu -->
				<div class="navbar-collapse collapse" id="navbarCategoryCollapse">
					<ul class="navbar-nav navbar-nav-scroll nav-pills-primary-soft text-center ms-auto p-2 p-xl-0">
						<!-- Home -->
						<li class="nav-item me-2" id="nav-home">
							<a class="nav-link tombol-nav active" href="#1">
								<i class="fa-solid fa-house me-2"></i>Home
							</a>
						</li>
						<!-- Anggota -->
						<li class="nav-item me-2" id="nav-anggota">
							<a class="nav-link tombol-nav " href="#">
								<i class="fa-solid fa-user-plus me-2"></i>Anggota
							</a>
						</li>

						<!-- Medis -->
						<li class="nav-item me-2" id="nav-medis">
							<a class="nav-link tombol-nav " href="#">
								<i class="fa-solid fa-file-medical me-2"></i>Medis
							</a>
						</li>
					</ul>
				</div>

				<!-- bagian changelog dan profil -->
				<ul class="nav flex-row align-items-center list-unstyled ms-xl-auto">
					<!-- changelog dropdown START -->
					<li class="nav-item dropdown ms-0 ms-md-3">
						<!-- changelog button -->
						<a class="nav-notification btn btn-light p-0 mb-0" href="#" role="button"
							data-bs-toggle="dropdown" aria-expanded="true" data-bs-auto-close="outside">
							<i class="fa-solid fa-code ms-2 me-2 mt-2 mb-2"></i>
						</a>
						<!-- changelog dropdown menu START -->
						<div class="dropdown-menu dropdown-animation dropdown-menu-end dropdown-menu-size-md shadow-lg p-0 rounded-5"
							style="width:350px ; height: 430px;">
							<!-- card changelog -->
							<div class="card bg-transparent rounded-5 border-0">
								<!-- Card header -->
								<div
									class="card-header bg-transparent d-flex justify-content-between align-items-center border-bottom">
									<button type="button" class="btn btn-sm btn-primary position-relative mt-2">
										Version changelog
										<span
											class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
											v.4.0
										</span>
									</button>
								</div>
								<!-- deskripsi changelog -->
								<div class="card-body">
									<p class="f-6 font-monospace mb-1">Add :</p>
									<p class="f-6 font-monospace mb-1">- Fitur tambah rekam medis anggota</p>
									<p class="f-6 font-monospace mb-1">- Fitur lihat detail data anggota</p>
									<p class="f-6 font-monospace mb-1">- Validasi form input</p>
									<p class="f-6 font-monospace mb-1">- Toogle profil</p>
									<p class="f-6 font-monospace mb-1">- Navbar responsif</p>
									<hr>
									<p class="f-6 font-monospace mb-1">Optimized :</p>
									<p class="f-6 font-monospace mb-1">- Animasi dan transisi</p>
									<p class="f-6 font-monospace mb-1">- Tampilan</p>
									<hr>
									<p class="f-6 font-monospace mb-1">© 2022 M.Rendi Alamsyah <i
											class="fa-solid fa-code"></i></p>

								</div>
							</div>
						</div>
					</li>
					<!-- Notification dropdown END -->

					<!-- Profile dropdown START -->
					<li class="nav-item ms-3 dropdown">
						<!-- Avatar di navbar -->
						<a class="avatar avatar-sm p-0" href="#" id="profileDropdown" role="button"
							data-bs-auto-close="outside" data-bs-display="static" data-bs-toggle="dropdown"
							aria-expanded="false">
							<img class="avatar-img rounded-2" src="<?php echo base_url('assets/img/profile.jpeg') ?>"
								alt="avatar" width="40" height="40">
						</a>
						<ul class="dropdown-menu dropdown-animation dropdown-menu-end shadow pt-3 rounded-5"
							style="width: 280px; height:280px ;" aria-labelledby="profileDropdown">
							<!-- Profile info -->
							<li class="px-3 mb-3">
								<div class="d-flex align-items-center">
									<!-- Avatar -->
									<div class="avatar me-3">
										<img class="avatar-img rounded-circle shadow"
											src="<?php echo base_url('assets/img/profile.jpeg') ?>" alt="avatar"
											width="40" height="40">
									</div>
									<div>
										<a class="h6 mt-2 mt-sm-0" href="#">M.Rendi Alamsyah</a>
										<p class="small m-0">Admin</p>
									</div>
								</div>
							</li>
							<!-- Baris Informasi -->
							<li>
								<hr class="dropdown-divider">
							</li>
							<li><a class="dropdown-item text-center" href="#">TUGAS SISTEM INFORMASI</a></li>
							<li><a class="dropdown-item" href="#">Nama : M.Rendi Alamsyah </a></li>
							<li><a class="dropdown-item" href="#">NIM : 09021282126061</a></li>
							<li><a class="dropdown-item" href="#">Kelas : TI Reg B</a></li>
							<li>
								<hr class="dropdown-divider">
							</li>
							<button class="btn btn-danger bg-danger-soft-hover ms-3" href="#">Sign Out</button>
						</ul>
					</li>
					<!-- Profile dropdown END -->
				</ul>
				<!-- Profile and Notification START -->
			</div>
		</nav>
		<!-- Logo Nav END -->
	</header>

	<!-- auto load modal notifikasi -->
	<?php
    if (isset($_SESSION['eksekusi'])):
    ?>
	<script type="text/javascript">
		$(document).ready(function () {
			$("#modal-notif").modal('show');
		});
	</script>
	<?php
	    session_destroy();
    endif;
    ?>

	<!-- Modal Notifikasi -->
	<div class="modal fade" name="modal-notif" id="modal-notif" tabindex="-1" aria-labelledby="exampleModalLabel"
		aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content rounded-4 shadow">
				<div class="modal-header border-bottom-0 bg-primary bg-opacity-10">
					<h1 class="modal-title fs-5">
						<i class="fa-solid fa-bell me-2"></i>Notifikasi
					</h1>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body py-0 bg-primary bg-opacity-10">
					<!-- isi notifikasi -->
					<p class="text-center">
						<?php echo $_SESSION['eksekusi']; ?>
					</p>
				</div>
				<div class="modal-footer flex-column border-top-0 bg-primary bg-opacity-10">
					<button type="button" class="btn btn-secondary w-100 mx-0" data-bs-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>

	<!-- konten -->
	<div class="container" id="content"></div>

	<!-- ajax navbar -->
	<script type="text/javascript">
		viewhome();
		$(document).ready(function () {
			$(".nav-link").click(function () {
				$(".nav-link").removeClass("active");
				$(this).addClass("active");
			})

			$("#nav-home").click(function () {
				viewhome();
			})

			$("#nav-anggota").click(function () {
				viewtambah_anggota();
			})

			$("#nav-medis").click(function () {
				viewtambah_medis();
			})
		})

		function viewhome() {
			$.ajax({
				method: "POST",
				url: "<?php echo base_url('c_home/getv_home') ?>",
				data: {}
			})
				.done(function (msg) {
					$("#content").html(msg);
				});
		}

		function viewtambah_anggota() {
			$.ajax({
				method: "POST",
				url: "<?php echo base_url('c_home/getv_tambah_anggota') ?>",
				data: {}
			})
				.done(function (msg) {
					$("#content").html(msg);
				});
		}

		function viewtambah_medis() {
			$.ajax({
				method: "POST",
				url: "<?php echo base_url('c_home/getv_tambah_medis') ?>",
				data: {}
			})
				.done(function (msg) {
					$("#content").html(msg);
				});
		}
	</script>

	<!-- Footer -->
	<div class="container">
		<footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
			<div class="col-md-4 d-flex align-items-center">
				<!-- logo footer -->
				<a href="<?php echo base_url() ?>" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
					<img src="<?php echo base_url('assets/img/logo-footer-baru.png') ?>" alt="Logo" width="20"
						height="20" class="justify-content-center">
					<img src="<?php echo base_url('assets/img/text-logo-footer.png') ?>" alt="Logo" width="80"
						height="20" class="justify-content-center">
				</a>
				<!-- text footer -->
				<span class="mb-3 mb-md-0 text-muted">© 2022 M.Rendi Alamsyah <i class="fa-solid fa-code"></i></span>
			</div>
			<!-- logo sosmed -->
			<ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
				<li class="ms-3"><a class="text-muted" href="#">
						<h5><i class="fa-brands fa-twitter"></i></h5>
					</a></li>
				<li class="ms-3"><a class="text-muted" href="#">
						<h5><i class="fa-brands fa-instagram"></i></h5>
					</a></li>
				<li class="ms-3"><a class="text-muted" href="#">
						<h5><i class="fa-brands fa-facebook"></i></h5>
					</a></li>
			</ul>
		</footer>
	</div>
</body>

</html>