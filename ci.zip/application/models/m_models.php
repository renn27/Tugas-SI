<?php
defined('BASEPATH') or exit('No direct script access allowed');

class m_models extends CI_Model
{

    function getDataAnggota()
    {
        $query = $this->db->get('anggota_bpjs');
        return $query->result();
    }

    function getDataMedis()
    {
        $query = $this->db->get('rekam_medis');
        return $query->result();
    }

    function insertDataAnggota($data)
    {
        $this->db->insert('anggota_bpjs', $data);
    }

    function insertDataMedis($data)
    {
        $this->db->insert('rekam_medis', $data);
    }

    function getDataAnggotaDetail($id_anggota)
    {
        $this->db->where('id_anggota', $id_anggota);
        $query = $this->db->get('anggota_bpjs');
        return $query->row();
    }

    function getDataMedisDetail($id_rekam_medis)
    {
        $this->db->where('id_rekam_medis', $id_rekam_medis);
        $query = $this->db->get('rekam_medis');
        return $query->row();
    }

    function updateDataAnggota($id_anggota, $data)
    {
        $this->db->where('id_anggota', $id_anggota);
        $this->db->update('anggota_bpjs', $data);
    }

    function updateDataMedis($id_rekam_medis, $data)
    {
        $this->db->where('id_rekam_medis', $id_rekam_medis);
        $this->db->update('rekam_medis', $data);
    }

    function deleteDataAnggota($id_anggota)
    {
        $this->db->where('id_anggota', $id_anggota);
        $this->db->delete('anggota_bpjs');
    }

    function deleteDataMedis($id_rekam_medis)
    {
        $this->db->where('id_rekam_medis', $id_rekam_medis);
        $this->db->delete('rekam_medis');
    }

    function getDataMedisAnggotaDetail($id_anggota)
    {
        $this->db->where('id_anggota', $id_anggota);
        $query = $this->db->get('rekam_medis');
        return $query->result();
    }

}